//
// Test MPI_File_read
//
#include <stdio.h>
#include "mpi.h"

#define F_LEN 1000

int main(int argc, char *argv[])
{

    MPI_File fh;
    MPI_Offset pt;
    MPI_Status status;
    MPI_Info info;
    int i;
    int ret;
    int count;
    int buf[F_LEN];
    int Rank_world, Size_world;
    char filename[10] = "test.data";

    ret = MPI_Init(&argc, &argv);
    ret = MPI_Comm_rank(MPI_COMM_WORLD, &Rank_world);
    ret = MPI_Comm_size(MPI_COMM_WORLD, &Size_world);

    pt = Rank_world * F_LEN * sizeof(int);

    MPI_File_open(MPI_COMM_WORLD, filename, MPI_MODE_RDONLY, MPI_INFO_NULL, &fh);
    MPI_File_set_view(fh, pt, MPI_INT, MPI_INT, "native", MPI_INFO_NULL);

    ret = MPI_File_read(fh, &buf, F_LEN, MPI_INT, &status);
//  for(i=0;i<F_LEN;i++){
//      printf("buf[%d]=%d\n",i,buf[i]);
//  }
    if (ret != MPI_SUCCESS) {
        fprintf(stderr, "Error: MPI_File_read ret=%d\n", ret);
        fflush(stderr);
    }

    ret = MPI_Get_count(&status, MPI_INT, &count);
    if (count != F_LEN) {
        fprintf(stderr, "MPI_File_read ret=%d count=%d F_LEN=%d Error\n",
                ret, count, F_LEN);
        fflush(stderr);
    } else {
        fprintf(stderr, "MPI_File_read ret=%d count=%d F_LEN=%d\n", ret,
                count, F_LEN);
        fflush(stderr);
    }

    MPI_File_close(&fh);
    MPI_Finalize();

    return 0;
}
